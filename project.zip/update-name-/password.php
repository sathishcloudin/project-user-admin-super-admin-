<form class="form" action="password_change.php" method="post">
        <h1 class="logout-title">conifirm password</h1>
        <input type="password" class="input" name="password" placeholder=" old Password" required>
        <input type="password" class="input" name="epassword" placeholder=" new Password" required>
        <input type="password" class="input" name="cpassword" placeholder="conifirm Password" required>
        <input type="submit" name="re_password" value="submit" class="btn btn-primary">
        <p class="link"><a href="logout.php">Click to logout</a></p>
     </form>

 <?php
